package com.touchrec

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (24 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }
        root.addView(TextView(this).apply {
            text = "Touch Recorder"
            textSize = 26f
        })
        root.addView(TextView(this).apply {
            textSize = 16f
            setPadding(0, pad, 0, pad)
            text = "1. Tap the button below, find \"Touch Recorder\" and turn it ON.\n\n" +
                    "2. A floating bar appears on top of every app.\n\n" +
                    "3. Tap ● Rec, then tap / hold / swipe anywhere. Tap ■ Stop when done.\n\n" +
                    "4. Tap ▶ Play to replay. ↻ turns looping on/off.\n\n" +
                    "Drag the bar by the ⠿ handle. Keep the same screen orientation for recording and playback."
        })
        root.addView(Button(this).apply {
            text = "Open Accessibility settings"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        })
        setContentView(root)
    }
}
