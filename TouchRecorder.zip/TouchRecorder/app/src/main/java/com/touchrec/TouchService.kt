package com.touchrec

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Point
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import kotlin.math.hypot

/** One recorded finger gesture: when it started, how long it lasted, and the exact path. */
class Gesture(val startMs: Long, val durMs: Long, val pts: List<FloatArray>)

class TouchService : AccessibilityService() {

    private val BASE = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
    private val NO_TOUCH = WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE

    private lateinit var wm: WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private val token = Any()

    private lateinit var overlay: View
    private lateinit var overlayLp: WindowManager.LayoutParams
    private lateinit var panel: LinearLayout
    private lateinit var panelLp: WindowManager.LayoutParams
    private lateinit var recBtn: TextView
    private lateinit var playBtn: TextView
    private lateinit var loopBtn: TextView
    private lateinit var info: TextView

    private var gestures = mutableListOf<Gesture>()
    private var totalMs = 0L
    private var recW = 0
    private var recH = 0

    private var recording = false
    private var playing = false
    private var loop = false

    private var recStart = 0L
    private var tracking = false
    private var curDown = 0L
    private var curPts = ArrayList<FloatArray>()
    private var playStart = 0L

    // ---------------------------------------------------------------- lifecycle

    override fun onServiceConnected() {
        if (this::overlay.isInitialized) return
        wm = getSystemService(WINDOW_SERVICE) as WindowManager

        // Full-screen capture layer (only touchable while recording).
        overlay = View(this)
        overlayLp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            BASE or NO_TOUCH,
            PixelFormat.TRANSLUCENT
        )
        if (Build.VERSION.SDK_INT >= 28) {
            overlayLp.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        }
        overlay.setOnTouchListener { _, e -> onRecordTouch(e); true }
        wm.addView(overlay, overlayLp)

        buildPanel()   // added after overlay so it stays on top
        load()
        updateUi()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(token)
        if (this::overlay.isInitialized) {
            try { wm.removeView(overlay) } catch (_: Exception) {}
            try { wm.removeView(panel) } catch (_: Exception) {}
        }
        super.onDestroy()
    }

    // ---------------------------------------------------------------- UI

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun btn(label: String, onClick: () -> Unit) = TextView(this).apply {
        text = label
        setTextColor(Color.WHITE)
        textSize = 14f
        gravity = Gravity.CENTER
        setPadding(dp(12), dp(10), dp(12), dp(10))
        setOnClickListener { onClick() }
    }

    private fun buildPanel() {
        val handle = TextView(this).apply {
            text = "⠿"
            setTextColor(Color.LTGRAY)
            textSize = 18f
            setPadding(dp(12), dp(8), dp(8), dp(8))
            setOnTouchListener(object : View.OnTouchListener {
                var sx = 0f; var sy = 0f; var ox = 0; var oy = 0
                override fun onTouch(v: View, e: MotionEvent): Boolean {
                    when (e.actionMasked) {
                        MotionEvent.ACTION_DOWN -> {
                            sx = e.rawX; sy = e.rawY; ox = panelLp.x; oy = panelLp.y
                        }
                        MotionEvent.ACTION_MOVE -> {
                            panelLp.x = ox + (e.rawX - sx).toInt()
                            panelLp.y = oy + (e.rawY - sy).toInt()
                            wm.updateViewLayout(panel, panelLp)
                        }
                    }
                    return true
                }
            })
        }
        recBtn = btn("● Rec") { toggleRec() }
        playBtn = btn("▶ Play") { togglePlay() }
        loopBtn = btn("↻") { loop = !loop; updateUi() }
        info = TextView(this).apply {
            setTextColor(Color.LTGRAY)
            textSize = 12f
            setPadding(dp(6), 0, dp(14), 0)
        }
        panel = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = GradientDrawable().apply {
                setColor(0xE6202124.toInt())
                cornerRadius = dp(28).toFloat()
            }
            addView(handle); addView(recBtn); addView(playBtn); addView(loopBtn); addView(info)
        }
        panelLp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            BASE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(16); y = dp(120)
        }
        wm.addView(panel, panelLp)
    }

    private fun updateUi() {
        recBtn.text = if (recording) "■ Stop" else "● Rec"
        recBtn.setTextColor(if (recording) Color.parseColor("#FF5252") else Color.WHITE)
        playBtn.text = if (playing) "■ Stop" else "▶ Play"
        loopBtn.alpha = if (loop) 1f else 0.35f
        info.text = "${gestures.size} actions"
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun setOverlayTouchable(t: Boolean) {
        overlayLp.flags = if (t) BASE else BASE or NO_TOUCH
        if (overlay.isAttachedToWindow) wm.updateViewLayout(overlay, overlayLp)
    }

    private fun setPanelTouchable(t: Boolean) {
        panelLp.flags = if (t) BASE else BASE or NO_TOUCH
        if (panel.isAttachedToWindow) wm.updateViewLayout(panel, panelLp)
    }

    @Suppress("DEPRECATION")
    private fun screenSize(): Point {
        val p = Point()
        wm.defaultDisplay.getRealSize(p)
        return p
    }

    // ---------------------------------------------------------------- recording

    private fun toggleRec() {
        if (playing) return
        if (recording) stopRec() else startRec()
    }

    private fun startRec() {
        gestures = mutableListOf()
        totalMs = 0
        val s = screenSize()
        recW = s.x; recH = s.y
        recording = true
        tracking = false
        recStart = SystemClock.uptimeMillis()
        overlay.setBackgroundColor(0x12FF0000)   // faint red tint = recording
        setOverlayTouchable(true)
        updateUi()
    }

    private fun stopRec() {
        recording = false
        tracking = false
        totalMs = SystemClock.uptimeMillis() - recStart
        gestures.lastOrNull()?.let { totalMs = maxOf(totalMs, it.startMs + it.durMs) }
        overlay.setBackgroundColor(0)
        setOverlayTouchable(false)
        save()
        updateUi()
    }

    private fun onRecordTouch(e: MotionEvent) {
        if (!recording) return
        // Single finger only: we follow pointer 0 and ignore any extra fingers.
        val ox = e.rawX - e.x
        val oy = e.rawY - e.y
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                tracking = true
                curDown = e.eventTime
                curPts = arrayListOf(floatArrayOf(e.rawX, e.rawY))
            }
            MotionEvent.ACTION_MOVE -> if (tracking) {
                for (i in 0 until e.historySize) {
                    curPts.add(floatArrayOf(e.getHistoricalX(0, i) + ox, e.getHistoricalY(0, i) + oy))
                }
                curPts.add(floatArrayOf(e.getX(0) + ox, e.getY(0) + oy))
            }
            MotionEvent.ACTION_UP -> if (tracking) {
                tracking = false
                curPts.add(floatArrayOf(e.getX(0) + ox, e.getY(0) + oy))
                finishGesture(e.eventTime)
            }
            MotionEvent.ACTION_CANCEL -> tracking = false
        }
    }

    private fun finishGesture(upTime: Long) {
        val start = curPts.first()
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        val moved = curPts.any { hypot(it[0] - start[0], it[1] - start[1]) > slop }
        // Finger jitter inside the touch slop is dropped so a tap/hold can never turn into a drag.
        val pts = if (moved) curPts.toList() else listOf(start)
        val dur = (upTime - curDown).coerceIn(1L, 59000L)
        val g = Gesture(curDown - recStart, dur, pts)
        gestures.add(g)
        updateUi()

        // The overlay swallowed the real touch, so perform it for real right now.
        setOverlayTouchable(false)
        dispatch(g) { if (recording) setOverlayTouchable(true) }
    }

    // ---------------------------------------------------------------- playback

    private fun togglePlay() {
        if (recording) return
        if (playing) stopPlay() else startPlay()
    }

    private fun startPlay() {
        if (gestures.isEmpty()) { toast("Nothing recorded yet"); return }
        val s = screenSize()
        if (s.x != recW || s.y != recH) {
            toast("Screen size/orientation changed since recording. Re-record.")
            return
        }
        playing = true
        updateUi()
        playStart = SystemClock.uptimeMillis()
        schedule(0)
    }

    private fun stopPlay() {
        playing = false
        handler.removeCallbacksAndMessages(token)
        updateUi()
    }

    private fun schedule(i: Int) {
        if (!playing) return
        if (i >= gestures.size) {
            if (loop) {
                playStart += maxOf(totalMs, 200L)
                schedule(0)
            } else {
                handler.postAtTime({ stopPlay() }, token, playStart + totalMs)
            }
            return
        }
        val g = gestures[i]
        handler.postAtTime({
            if (playing) dispatch(g) {}
        }, token, playStart + g.startMs)
        schedule(i + 1)
    }

    // ---------------------------------------------------------------- gesture injection

    private fun dispatch(g: Gesture, done: () -> Unit) {
        val s = screenSize()
        val path = Path()
        g.pts.forEachIndexed { i, a ->
            val x = a[0].coerceIn(0f, s.x - 1f)
            val y = a[1].coerceIn(0f, s.y - 1f)
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        val gd = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, g.durMs))
            .build()

        // If the gesture starts under our own control bar, let it pass through the bar.
        val f = g.pts[0]
        val underPanel = panel.isShown &&
                f[0] >= panelLp.x && f[0] <= panelLp.x + panel.width &&
                f[1] >= panelLp.y && f[1] <= panelLp.y + panel.height
        if (underPanel) setPanelTouchable(false)

        val finish = {
            if (underPanel) setPanelTouchable(true)
            done()
        }
        val ok = dispatchGesture(gd, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) { finish() }
            override fun onCancelled(gestureDescription: GestureDescription?) { finish() }
        }, null)
        if (!ok) finish()
    }

    // ---------------------------------------------------------------- storage

    private fun save() {
        try {
            val arr = JSONArray()
            gestures.forEach { g ->
                val p = JSONArray()
                g.pts.forEach { p.put(JSONArray().put(it[0].toDouble()).put(it[1].toDouble())) }
                arr.put(JSONObject().put("s", g.startMs).put("d", g.durMs).put("p", p))
            }
            val o = JSONObject().put("w", recW).put("h", recH).put("t", totalMs).put("g", arr)
            File(filesDir, "rec.json").writeText(o.toString())
        } catch (_: Exception) {}
    }

    private fun load() {
        try {
            val f = File(filesDir, "rec.json")
            if (!f.exists()) return
            val o = JSONObject(f.readText())
            recW = o.getInt("w"); recH = o.getInt("h"); totalMs = o.getLong("t")
            val arr = o.getJSONArray("g")
            val list = mutableListOf<Gesture>()
            for (i in 0 until arr.length()) {
                val g = arr.getJSONObject(i)
                val p = g.getJSONArray("p")
                val pts = (0 until p.length()).map {
                    val a = p.getJSONArray(it)
                    floatArrayOf(a.getDouble(0).toFloat(), a.getDouble(1).toFloat())
                }
                list.add(Gesture(g.getLong("s"), g.getLong("d"), pts))
            }
            gestures = list
        } catch (_: Exception) {}
    }
}
